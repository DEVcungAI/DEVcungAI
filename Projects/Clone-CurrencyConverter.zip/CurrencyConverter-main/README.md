# CurrencyConverter
A simple currency converter app made in C# (WPF). Using exchangerate-api.com for currencies data.
![CurrencyConverterGithub](https://user-images.githubusercontent.com/77244734/152640049-82d95417-5690-4517-a929-13e1ef89d6d2.PNG)
